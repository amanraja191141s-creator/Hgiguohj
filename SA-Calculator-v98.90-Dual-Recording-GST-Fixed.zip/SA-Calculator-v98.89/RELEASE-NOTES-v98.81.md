# SA Calculator v98.81 — Clean Reference Reset

This release replaces the accumulated action-time tool UI overrides with one canonical reference presentation layer based on the supplied 720x1560 GST action-time recording.

### UI reset
- Tool header, content boundaries, card heights, field labels, entry text, result rows and keypad geometry retuned to the measured reference proportions.
- GST card/result surface rebuilt without nested-grid collision.
- Shared keypad uses the large four-row reference geometry and tall action key.
- Currency/Unit selector surfaces remain single-selector and touch-safe.
- SIP/Saving supporting reference behaviors retained.

### Action-time
- Removed animated scroll races from keypad focus and result reveal paths.
- Preserved explicit result commit semantics.
- Preserved Currency/Unit swap behavior.

### Validation
- 89/89 release tests pass.
- Web bundle synchronized.
- CI source/test-entry validation synchronized to v98.81.
