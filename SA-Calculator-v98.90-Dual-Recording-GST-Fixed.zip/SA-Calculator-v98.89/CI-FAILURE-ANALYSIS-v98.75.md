# SA Calculator v98.75 — CI Failure Analysis & Hotfix

## Root cause
The release `assets/js/app.js` and generated `www/assets/js/app.js` contained the v98.75 tool-hardening suffix with literal `\\n` characters instead of real line breaks. That made Node's syntax validator fail at the first character of the suffix.

The workflow therefore stopped at **Validate JavaScript syntax**. All later build/test/Capacitor/Gradle steps were not executed; their `0s` entries were skipped steps, not successful executions.

## Fix
- Rewrote the corrupted suffix using real line breaks.
- Re-synchronized root and `www/` JavaScript/CSS assets.
- Added a pre-dependency JavaScript syntax gate to fail immediately and clearly.
- Added a regression test that rejects the exact literal escaped-newline corruption.
- Kept v98.75 release identity and Android version code unchanged.

## Local validation
- JavaScript syntax: PASS
- Web bundle generation: PASS
- Release regression suite: **57/57 PASS**
- Root/www authoritative JS and tool CSS: byte-identical
- Workflow YAML parsing: PASS
- ZIP integrity: validated during packaging

## Expected CI order
Checkout → setup → exact source selection → source verification → **early syntax gate** → npm install → dependency verification → build → 57-test release suite → web bundle verification → Capacitor sync → Android branding → Gradle/APK build → APK identity/checksum → artifact upload.
