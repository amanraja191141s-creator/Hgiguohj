import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const html=read('index.html'), css=read('assets/css/tool-reference-ui.css'), js=read('assets/js/app.js');
const pkg=JSON.parse(read('package.json'));
test('GST quick rates share the Add rate entry row, not a separate lower row',()=>{
  assert.match(html,/<div class="gst-rate-entry-row">[\s\S]*?id="tax-rate"[\s\S]*?class="gst-quick-rates"[\s\S]*?data-gst-rate="5"[\s\S]*?data-gst-rate="18"[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/);
  const final=css.slice(css.lastIndexOf('v98.90 — authoritative GST layout'));
  assert.match(final,/\.gst-rate-entry-row\s*\{[\s\S]*?display:flex !important/);
  assert.match(final,/\.gst-rate-entry-row \.reference-input-suffix\s*\{[\s\S]*?flex:1 1 0 !important/);
  assert.match(final,/\.gst-quick-rates\s*\{[\s\S]*?flex:0 0 auto !important/);
});
test('GST placeholders depend on explicit empty state, never :only-child',()=>{
  const final=css.slice(css.lastIndexOf('v98.90 — authoritative GST layout'));
  assert.match(final,/#tax-orig\.is-empty::after/);
  assert.match(final,/#tax-rate\.is-empty::after/);
  assert.match(js,/textSpan\.classList\.toggle\('is-empty', isEmpty\)/);
  assert.match(js,/target\.classList\.toggle\('is-empty', isEmpty\)/);
  assert.doesNotMatch(final,/:has\(> \.input-cursor:only-child\)/);
});
test('only the active GST field retains a visible caret and long values auto-scroll horizontally',()=>{
  assert.match(js,/el\.querySelectorAll\('\.input-text > \.input-cursor'\)\.forEach\(cursor => cursor\.remove\(\)\)/);
  assert.match(js,/target\.scrollLeft = Math\.max\(0, right - target\.clientWidth \+ 8\)/);
  assert.match(css,/#tax-orig\.input-val-box,\s*#screen-viewport #screen-salestax #tax-rate\.input-val-box\s*\{[\s\S]*?overflow-x:auto !important/);
});
test('GST quick-rate selection renders a percent suffix and places the caret before it',()=>{
  assert.match(js,/renderToolInputValue\(target, `\$\{value\}%`, String\(value\)\.length\)/);
});
test('v98.90 release identity and cache namespace agree',()=>{
  assert.equal(pkg.version,'1.99.04-v98.90');
  assert.equal(pkg.androidVersionCode,1099110);
  assert.match(read('assets/js/app.js'),/const APP_VERSION = '1\.99\.04-v98\.90'/);
  assert.match(read('service-worker.js'),/sa-calculator-v98-90-dual-recording-gst-layout-placeholder-caret-v9890/);
  assert.ok(pkg.scripts['test:release'].includes('tests/gst-row-placeholder-caret-v9889.test.mjs'));
});
