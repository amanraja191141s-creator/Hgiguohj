# SA Calculator v98.90 — Dual Recording GST Corrections

## Recording findings
- GST amount and rate values overlapped their placeholders after keypad entry.
- The rate label, input and 5% / 18% quick-rate buttons did not maintain a stable row.
- Amount and rate card geometry diverged across recorded frames.
- Android text selection UI could appear over custom keypad-driven fields.
- The GST result surface appeared dark in one recording despite the light GST form.

## Corrections
- One explicit empty-state class on the field and text span controls placeholder visibility.
- Amount and rate cards share matching outer dimensions and icon/field grid geometry.
- Quick rates remain in the same flex row as Add rate.
- Exactly one active GST field renders the virtual caret; inactive field caret is hidden.
- Long values scroll horizontally inside the active field. Native text selection/callout is disabled for custom GST fields while app-managed tap-to-place caret remains.
- GST result card is forced to a light, auto-height, non-clipping surface.
- Existing GST calculation and state/mode handlers remain unchanged.

## Identity
- Version: `1.99.04-v98.90`
- Android versionCode: `1099110`
- Service worker cache: `sa-calculator-v98-90-dual-recording-gst-layout-placeholder-caret-v9890`
